# mediabook
This is a clone of **facebook website** using HTML and CSS only. And I've rebranded it as a **MediaBook**. This is only a design of Facebook Website.

Look at [live demo](https://aashishpanthi.github.io/mediabook/): https://aashishpanthi.github.io/mediabook/
