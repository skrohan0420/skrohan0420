# Jobs-Safari--JavaScript
A Job Portal built with HTML, CSS & JavaScript

# Here is how website looks 
<img src='https://github.com/sauravsharmaz/Jobs-Safari--JavaScript/blob/main/assets/images/snaps.png'/>
