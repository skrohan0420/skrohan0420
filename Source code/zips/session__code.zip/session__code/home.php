<?php
session_start();
if(!isset($_SESSION['name'])){
	echo"you are logout";
	header("location:index.php");
}
else{
	echo"<p> or you can logout</p><a href='logout.php'>logout</a>";
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>document</title>
</head>
<body>
	<h3>name <?php echo $_SESSION['name']?></h2>
	<h1> email<?echo $_SESSION['email']?></h1>
	<h2>fav_place <?echo $_SESSION['fav_place']?></h3>

</body>
</html>

