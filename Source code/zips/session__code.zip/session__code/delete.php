<?php
session_start();
if(isset($_SESSION['name'])){
	echo"you are log out";
	header('location:index.php');
}
else{
	echo"<p>or you can logout by</p><a href='logout.php'>logout</a>";
}
?>
<?php
include "connection.php";
$id = $_GET['id'];

$deletequery="delete from hello where id=$id";
$res=mysqli_query($conn,$deletequery);

if($res){
	echo"delete is successful";
	header('location.php');
}
else{
	echo 'data not deleted';
}
?>







