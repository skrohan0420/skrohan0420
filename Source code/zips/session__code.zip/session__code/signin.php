<!DOCTYPE html>
<html>
<head>
	
	<title>Registartion</title>
</head>
<body>
	<form method="post" action="action.php">
	<div class="container">
	<div class="form-group">
		<label for="name">Name:</label>
		<input id="name" class="form-control" type="name" name="name" required>
	</div>

<div class="form-group">
		<label for="email">email:</label>
		<input id="email" class="form-control" type="email" name="email" required>
	</div>

<div class="form-group">
		<label for="fav_place">fav_place:</label>
		<input id="fav_place" class="form-control" type="fav_place" name="fav_place" >
	</div>

<div class="form-group">
		<label for="password">password:</label>
		<input id="password" class="form-control" type="password" name="password" >
	</div>
	    <button type="reset">Reset</button>
        <button type="submit">submit</button>

	
</form>
</div>
</body>
</html>


