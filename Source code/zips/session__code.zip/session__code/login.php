<?php
session_start();
if(isset($_SESSION['name'])){
	echo"you are login";
	header("location:home.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>login</title>
</head>
<body>
	<form method="post" action="">
		<div class="form-group">
			<label for="email"> Email:</label>
			<input id="email" class="form-control" type="email" name="email" required>
		</div>
		<div class="form-group">
			<label for="password"> password:</label>
			<input id="password" class="form-control" type="password" name="password">
			<button type="submit">login</button>
		</div>
	</form>
</body>
<?php
	include 'connection.php';
	if(isset($_POST['submit'])){
		$email=$_POST['email'];
		$password=$_POST['password'];
		$searchquery= "SELECT * from hello where email= $email and password=$password";
		$res=mysqli_query($conn,$searchquery);
		$data=mysqli_fetch_assoc($res);
		$_SESSION['name']=$data['name'];
		$_SESSION['email']=$data['email'];
		$_SESSION['fav_place']=$data['fav_place'];
		$row=mysqli_num_rows($res);
		if($row>0){
			echo"login successful";
			header("location:home.php");
		} 

		else{
			echo"invaild email or password";

		}
	}
?>
</html>