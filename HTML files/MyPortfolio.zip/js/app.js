/*===== SCROLL REVEAL ANIMATION =====*/
const sr = ScrollReveal({
    origin: 'top',
    distance: '80px',
    duration: 2000,
    reset: true
});

/*SCROLL HOME*/
sr.reveal('.sr_1', {});
sr.reveal('.sr_2', { delay: 200 });
sr.reveal('.sr_3', { delay: 400 });
sr.reveal('.sr_4', { delay: 600 });
sr.reveal('.sr_5', { interval: 200 });

let observerConfig = {
    root: null,
    rootMargin: '200px',
    threshold: 1
};
let observer = new IntersectionObserver(observerFn, observerConfig);

const type = document.querySelector(".type");

observer.observe(type);

function observerFn(entries) {
    if (entries[0].isIntersecting) {
        type.classList.add("typewrite");
    } else if (!entries[0].isIntersecting) {
        type.classList.remove("typewrite");
    }
}

//! Menu
const dotMenu = document.querySelector(".dot_menu");
const menu = document.querySelector(".navbar__navmenu");

dotMenu.addEventListener('click', () => {
    if (menu.style.display != 'flex') {
        menu.style.display = 'flex';
    } else {
        menu.style.display = 'none';
    }
})