# terminal_minecraft

in linux compile with
`gcc terminal_minecraft.c -lm -lX11`

controls:
- use arrow keys for moving
- use w, a, s, d keys for changing view angles
- use space for placing block
- use shift + space for removing block

no collision detection etc.
