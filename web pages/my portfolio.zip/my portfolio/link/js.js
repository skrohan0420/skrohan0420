function open_Nav() 
					{
						document.getElementById("mySidenav").style.width = "250px";
					}

function close_Nav()
					{
						document.getElementById("mySidenav").style.width = "0";
					};
