<?php 
$conn = mysqli_connect("localhost","root","12345678","test");
if($conn){
    // echo 'database Connected <br>';
}else{
    echo 'database Error';
}



?>