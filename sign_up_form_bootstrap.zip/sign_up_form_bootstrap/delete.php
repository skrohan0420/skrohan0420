<?php
include "conn.php";


$id = $_GET['id'];

$q = "DELETE FROM `user_data` WHERE id = '$id'";


if(mysqli_query($conn, $q)){
    header('Location: view.php');
}else{
    echo "Cannot Delete Data";
}



?>